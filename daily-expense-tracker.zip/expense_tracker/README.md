# Daily Expense Tracker (CampusSolve Project #11)

## Setup & Run
```bash
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate
pip install -r requirements.txt
python main.py
```
