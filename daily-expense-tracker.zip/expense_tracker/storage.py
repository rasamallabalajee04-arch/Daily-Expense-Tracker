from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import List

from models import Expense


def load_expenses_json(filepath: Path) -> List[Expense]:
    filepath.parent.mkdir(parents=True, exist_ok=True)
    if not filepath.exists():
        save_expenses_json(filepath, [])
        return []

    try:
        raw_text = filepath.read_text(encoding="utf-8")
        data = json.loads(raw_text)
        if not isinstance(data, list):
            raise ValueError("Expected JSON root to be a list.")
    except (json.JSONDecodeError, ValueError, OSError):
        if filepath.exists():
            backup_path = filepath.with_suffix(".corrupt.bak")
            filepath.replace(backup_path)
        save_expenses_json(filepath, [])
        return []

    expenses: List[Expense] = []
    for item in data:
        if isinstance(item, dict):
            try:
                expenses.append(Expense.from_dict(item))
            except ValueError:
                continue
    return expenses


def save_expenses_json(filepath: Path, expenses: List[Expense]) -> None:
    filepath.parent.mkdir(parents=True, exist_ok=True)
    payload = [e.to_dict() for e in expenses]
    filepath.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def export_expenses_csv(filepath: Path, expenses: List[Expense]) -> None:
    filepath.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["id", "date", "amount", "category", "note"]
    with filepath.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for exp in expenses:
            writer.writerow(exp.to_dict())
