from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Callable, List, TypeVar

from analytics import (
    HAS_MATPLOTLIB,
    filter_expenses,
    plot_monthly_categories,
    summarize_month,
    write_markdown_report,
)
from models import ALLOWED_CATEGORIES, Expense
from storage import export_expenses_csv, load_expenses_json, save_expenses_json

T = TypeVar("T")

DATA_FILE = Path("data/expenses.json")
EXPORT_DIR = Path("exports")


def prompt_until_valid(prompt_text: str, validator: Callable[[str], T]) -> T:
    while True:
        raw = input(prompt_text)
        try:
            return validator(raw)
        except ValueError as err:
            print(f"  [Invalid input] {err} Please try again.")


def print_expenses_table(expenses: List[Expense]) -> None:
    if not expenses:
        print("\nNo matching expenses found.")
        return

    print(f"\n{'ID':<10} {'Date':<12} {'Category':<15} {'Amount':>10}  {'Note'}")
    print("-" * 75)
    for e in expenses:
        note_preview = e.note if len(e.note) <= 28 else e.note[:25] + "..."
        print(f"{e.id:<10} {e.date:<12} {e.category:<15} {e.amount:>10.2f}  {note_preview}")
    print("-" * 75)


def add_expense_flow(expenses: List[Expense]) -> None:
    today_str = datetime.now().strftime("%Y-%m-%d")
    print(f"\n--- Add Expense (tip: press Enter for today {today_str}) ---")

    def date_validator(s: str) -> str:
        return Expense.validate_date(today_str if not s.strip() else s)

    date_val = prompt_until_valid("Date (YYYY-MM-DD): ", date_validator)
    amount_val = prompt_until_valid("Amount: ", Expense.validate_amount)
    print(f"Categories: {', '.join(ALLOWED_CATEGORIES)}")
    cat_val = prompt_until_valid("Category: ", Expense.validate_category)

    def note_validator(s: str) -> str:
        cleaned = " ".join(s.strip().split())
        if not cleaned:
            raise ValueError("Note cannot be blank.")
        return cleaned

    note_val = prompt_until_valid("Note: ", note_validator)

    expense = Expense(
        id=str(len(expenses) + 1).zfill(4),
        date=date_val,
        amount=amount_val,
        category=cat_val,
        note=note_val,
    )
    expenses.append(expense)
    save_expenses_json(DATA_FILE, expenses)
    print(f"Saved expense [{expense.id}] {expense.category} - {expense.amount:.2f} on {expense.date}.")


def monthly_summary_flow(expenses: List[Expense]) -> None:
    default_month = datetime.now().strftime("%Y-%m")
    raw_month = input(f"\nEnter month (YYYY-MM) [default {default_month}]: ").strip()
    month = raw_month or default_month

    summary = summarize_month(expenses, month)
    print(f"\n=== Monthly Summary: {summary['month']} ===")
    print(f"Entries       : {summary['count']}")
    print(f"Total Spent   : {summary['total']:.2f}")
    print(f"Average Entry : {summary['average']:.2f}")
    if summary["top_category"]:
        cat, amt = summary["top_category"]
        print(f"Top Category  : {cat} ({amt:.2f})")

    if summary["by_category"]:
        print("\nBy Category:")
        for cat, amt in summary["by_category"].items():
            print(f"  - {cat:<15}: {amt:>10.2f}")

    md_path = write_markdown_report(summary, EXPORT_DIR / f"summary_{month}.md")
    print(f"\nMarkdown report exported to: {md_path}")

    if HAS_MATPLOTLIB:
        chart_path = plot_monthly_categories(summary, EXPORT_DIR / f"chart_{month}.png")
        if chart_path:
            print(f"Chart saved to: {chart_path}")
    else:
        print("Matplotlib not installed; skipping chart generation.")


def search_flow(expenses: List[Expense]) -> None:
    print("\n--- Search & Filter Expenses (leave blank to skip filter) ---")
    keyword = input("Keyword in note/category: ").strip() or None
    category = input("Exact category: ").strip() or None
    month = input("Month (YYYY-MM): ").strip() or None

    matches = filter_expenses(expenses, keyword=keyword, category=category, month=month)
    print_expenses_table(matches)


def run() -> None:
    expenses = load_expenses_json(DATA_FILE)
    print(f"Loaded {len(expenses)} expense record(s) from {DATA_FILE}.")

    while True:
        print("\n=== Daily Expense Tracker ===")
        print("1. Add Expense")
        print("2. View All Expenses")
        print("3. Search / Filter Expenses")
        print("4. Monthly Summary & Export (MD + Chart)")
        print("5. Export All to CSV")
        print("6. Exit")

        choice = input("Select an option (1-6): ").strip()
        if choice == "1":
            add_expense_flow(expenses)
        elif choice == "2":
            print_expenses_table(expenses)
        elif choice == "3":
            search_flow(expenses)
        elif choice == "4":
            monthly_summary_flow(expenses)
        elif choice == "5":
            csv_path = EXPORT_DIR / "expenses_export.csv"
            export_expenses_csv(csv_path, expenses)
            print(f"Exported {len(expenses)} records to {csv_path}.")
        elif choice == "6":
            save_expenses_json(DATA_FILE, expenses)
            print("State saved. Goodbye!")
            break
        else:
            print("Please enter a number between 1 and 6.")


if __name__ == "__main__":
    run()
