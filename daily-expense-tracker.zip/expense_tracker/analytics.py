from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from models import Expense

try:
    import matplotlib.pyplot as plt
    HAS_MATPLOTLIB = True
except ImportError:
    HAS_MATPLOTLIB = False


def filter_expenses(
    expenses: List[Expense],
    keyword: Optional[str] = None,
    category: Optional[str] = None,
    month: Optional[str] = None,
) -> List[Expense]:
    results = expenses
    if category:
        cat_norm = category.strip().title()
        results = [e for e in results if e.category == cat_norm]
    if month:
        m_clean = month.strip()
        results = [e for e in results if e.date.startswith(m_clean)]
    if keyword:
        kw = keyword.strip().lower()
        results = [e for e in results if kw in e.note.lower() or kw in e.category.lower()]
    return results


def summarize_month(expenses: List[Expense], month: str) -> Dict:
    monthly = [e for e in expenses if e.date.startswith(month)]
    total = round(sum(e.amount for e in monthly), 2)
    count = len(monthly)
    avg = round(total / count, 2) if count else 0.0

    by_category: Dict[str, float] = defaultdict(float)
    for exp in monthly:
        by_category[exp.category] = round(by_category[exp.category] + exp.amount, 2)

    sorted_cats = sorted(by_category.items(), key=lambda x: x[1], reverse=True)
    top_category: Optional[Tuple[str, float]] = sorted_cats[0] if sorted_cats else None

    return {
        "month": month,
        "count": count,
        "total": total,
        "average": avg,
        "by_category": dict(sorted_cats),
        "top_category": top_category,
    }


def write_markdown_report(summary: Dict, output_path: Path) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f"# Expense Summary — {summary['month']}",
        "",
        f"- **Total Spent:** {summary['total']:,.2f}",
        f"- **Transaction Count:** {summary['count']}",
        f"- **Average per Entry:** {summary['average']:,.2f}",
    ]
    if summary["top_category"]:
        cat_name, cat_val = summary["top_category"]
        lines.append(f"- **Highest Category:** {cat_name} ({cat_val:,.2f})")

    lines.extend(["", "## Breakdown by Category", "", "| Category | Amount |", "| --- | ---: |"])
    for cat, amt in summary["by_category"].items():
        lines.append(f"| {cat} | {amt:,.2f} |")

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return output_path


def plot_monthly_categories(summary: Dict, output_path: Path) -> Optional[Path]:
    if not HAS_MATPLOTLIB:
        return None
    by_cat = summary.get("by_category", {})
    if not by_cat:
        return None

    output_path.parent.mkdir(parents=True, exist_ok=True)
    categories = list(by_cat.keys())
    values = list(by_cat.values())

    plt.figure(figsize=(8, 4.5))
    plt.bar(categories, values)
    plt.title(f"Spending by Category ({summary['month']})")
    plt.xlabel("Category")
    plt.ylabel("Amount")
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    return output_path
