from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
import uuid

ALLOWED_CATEGORIES = (
    "Food",
    "Transport",
    "Academics",
    "Utilities",
    "Entertainment",
    "Health",
    "Other",
)


@dataclass
class Expense:
    id: str
    date: str          # YYYY-MM-DD
    amount: float      # > 0
    category: str
    note: str

    @staticmethod
    def validate_date(date_str: str) -> str:
        cleaned = date_str.strip()
        try:
            parsed = datetime.strptime(cleaned, "%Y-%m-%d")
        except ValueError as exc:
            raise ValueError("Date must follow YYYY-MM-DD format (e.g., 2026-11-23).") from exc
        return parsed.strftime("%Y-%m-%d")

    @staticmethod
    def validate_amount(raw_amount: str | float, max_amount: float = 1_000_000.0) -> float:
        try:
            value = float(raw_amount)
        except (ValueError, TypeError) as exc:
            raise ValueError("Amount must be a valid number.") from exc

        if value <= 0:
            raise ValueError("Amount must be greater than 0.")
        if value > max_amount:
            raise ValueError(f"Amount cannot exceed {max_amount:,.2f}.")
        return round(value, 2)

    @staticmethod
    def validate_category(category: str) -> str:
        normalized = category.strip().title()
        if normalized not in ALLOWED_CATEGORIES:
            raise ValueError(
                f"Invalid category '{category}'. Choose from: {', '.join(ALLOWED_CATEGORIES)}."
            )
        return normalized

    @classmethod
    def create(cls, date_str: str, amount_raw: str | float, category: str, note: str) -> "Expense":
        valid_date = cls.validate_date(date_str)
        valid_amount = cls.validate_amount(amount_raw)
        valid_category = cls.validate_category(category)
        cleaned_note = " ".join(note.strip().split())
        if not cleaned_note:
            raise ValueError("Note cannot be empty.")

        return cls(
            id=str(uuid.uuid4())[:8],
            date=valid_date,
            amount=valid_amount,
            category=valid_category,
            note=cleaned_note,
        )

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict) -> "Expense":
        return cls.create(
            date_str=str(payload.get("date", "")),
            amount_raw=payload.get("amount", ""),
            category=str(payload.get("category", "")),
            note=str(payload.get("note", "")),
        )
